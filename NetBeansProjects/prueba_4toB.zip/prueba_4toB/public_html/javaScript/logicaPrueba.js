URL_SOAP = 'http://localhost/examen_cuarto_b/wsdl2.php?wsdl';
URL_RESTFUL = 'http://localhost/examen_cuarto_b/json2.php';
function registroProyectos() {
    var token="EXAMEN_4_B";
    localStorage["token"] = token;
    var id=0;
    localStorage["id"] = id;
    var cuerpo = '<Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">';
    cuerpo += '<Body>';
    cuerpo += '<guardar_proyecto xmlns="urn:server">';
    cuerpo += '<token>'+token+'</token>';
    cuerpo += '<nombre>'+$("#nombre").val()+'</nombre>';
    cuerpo += '<finicio>'+$("#finicio").val()+'</finicio>';
    cuerpo += '<ffinalizacion>'+$("#ffinal").val()+'</ffinalizacion>';
    cuerpo += '<tiempo>'+5+'</tiempo>';
    cuerpo += '<provincia>'+$("#provincia").val()+'</provincia>';
    cuerpo += '<canton>'+$("#canton").val()+'</canton>';
    cuerpo += '<pais>'+$("#pais").val()+'</pais>';
    cuerpo += '<extranjero>'+$("#º").val()+'</extranjero>';
    cuerpo += '<descripcion>'+$("#descripcion").val()+'</descripcion>';
    cuerpo += '<monto>'+$("#monto").val()+'</monto>';
    cuerpo += '<id>'+id+'</id>';
    cuerpo += '</guardar_proyecto>';
    cuerpo += '</Body>';
    cuerpo += '</Envelope>';
    $.ajax({
        url: URL_SOAP,
        data: cuerpo,
        type: 'POST',
        dataType: 'xml',
        contentType: 'text/xml',
        success: function (data, textStatus, jqXHR) {
            var mensaje = '';
            if (jqXHR.status == '200') {
                mensaje += '<div class="alert alert-success" role="alert">';
                mensaje += '    Registro con exito';
                mensaje += '</div>';
                $("#mensaje").html(mensaje);
                alert("Se ha registrado con exito el proyecto");
                location.href = "index.html";
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR.responseText);
            manejoErrores(jqXHR.responseText);
        }
    });
}
//var provincia='';

function listarProvincia() {
    var accion = "/listar_provincias";
    $.ajax({
        url: URL_RESTFUL + accion,
        type: 'GET',
        dataType: 'json',
        success: function (data, textStatus, jqXHR) {
            //  console.log(data);
            if (data.codigo) {
                manejoErroresJson(data.message, data.codigo);
            } else {
                var opcion = '';
                $.each(data, function (index, item) {
                    //console.log(item.nombre);
                    //var aux = $.param(item);
                    //externalPaciente = item.external;
                    var itemData = JSON.stringify(item);
                    // var nombre = $(this).find("nombre").text();
                    opcion += "<option\n\
                    value= '" + item.nombre + "'>" + item.nombre + "</option>";
                    listarCanton("AZUAY");
                });
                $("#provincia").html(opcion);
            }

        }, error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR);
            alert("ERROR");
        }
    });
}

function listarCanton(provincia) {
    var accion = "/listar_cantones/" + provincia;
    $.ajax({
        url: URL_RESTFUL + accion,
        type: 'GET',
        dataType: 'json',
        success: function (data, textStatus, jqXHR) {
            // console.log(data);
            if (data.codigo) {
                manejoErroresJson(data.message, data.codigo);
            } else {
                var opcion = '';
                $.each(data, function (index, item) {
                  //  console.log(item.canton);
                    //var aux = $.param(item);
                    //externalPaciente = item.external;
                    var itemData = JSON.stringify(item);
                    // var nombre = $(this).find("nombre").text();
                    opcion += "<option value= '" + item.canton + "'>" + item.canton + "</option>";
                });
                $("#canton").html(opcion);
            }

        }, error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR);
            alert("ERROR");
        }
    });
}

function manejoErrores(xml) {
    var xmlData = $.parseXML(xml);
    var error = $(xml).find("faultstring").text();
    console.log(error);
    var mensaje = '<div class="alert alert-danger">';
    mensaje += error;
    mensaje += '</div>';

    $("#mensaje").html(mensaje);
}

function manejoErroresJson(error, codigo) {
    if (codigo == "401") {
        mensaje = "Hubo un error al momento de solicitar la informacion,\n\
                por favor pongase en contacto";
    }
    //console.log(error);
    var mensaje = '<div class="alert alert-danger">';
    mensaje += error;
    mensaje += '</div>';
    $("#mensaje").html(mensaje);
}

function esExtranjero(val){
    if(val=="si"){
        document.getElementById('canton').style.display = 'block';
        document.getElementById('provincia').style.display = 'block';
    }
}